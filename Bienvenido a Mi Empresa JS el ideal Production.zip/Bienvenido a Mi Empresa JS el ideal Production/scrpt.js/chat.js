const socket = io();

socket.on('mensaje', (msg) => {
    const chatBox = document.getElementById('chat-box');
    const mensaje = document.createElement('p');
    mensaje.textContent = msg;
    chatBox.appendChild(mensaje);
});

function enviarMensaje() {
    const input = document.getElementById('mensaje');
    socket.emit('mensaje', input.value);
    input.value = "";
}
socket.on('historial', (mensajes) => {
    const chatBox = document.getElementById('chat-box');
    mensajes.forEach(mensaje => {
        const p = document.createElement('p');
        p.textContent = mensaje.texto;
        chatBox.appendChild(p);
    });
}   );

document.getElementById('enviar').addEventListener('click', enviarMensaje);
document.getElementById('mensaje').
addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        enviarMensaje();
    }
}); 
// Asegúrate de que el servidor esté corriendo y que la conexión a MongoDB esté establecida correctamente.
// Puedes probar el chat abriendo múltiples pestañas del navegador y enviando mensajes desde cada una.  
// Los mensajes deberían aparecer en todas las pestañas en tiempo real.
// Además, los mensajes enviados se guardarán en la base de datos MongoDB y se cargarán al iniciar el chat.

// Asegúrate de que el servidor esté corriendo y que la conexión a MongoDB esté establecida correctamente.  
// Puedes probar el chat abriendo múltiples pestañas del navegador y enviando mensajes desde cada una.