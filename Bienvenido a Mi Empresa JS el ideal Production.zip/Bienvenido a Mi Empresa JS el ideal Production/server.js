const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/chatDB', {
    useNewUrlParser: true, 
    useUnifiedTopology: true
});

const mensajeSchema = new mongoose.Schema({ texto: String, fecha: Date });
const Mensaje = mongoose.model('Mensaje', mensajeSchema);

io.on('connection', (socket) => {
    Mensaje.find().then(mensajes => socket.emit('historial', mensajes));

    socket.on('mensaje', (msg) => {
        const nuevoMensaje = new Mensaje({ texto: msg, fecha: new Date() });
        nuevoMensaje.save();
        io.emit('mensaje', msg);
    });

});
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');  
const app = express();
const server = http.createServer(app);  
const io = socketIo(server);
app.use(express.static('public'));  // Servir archivos estáticos desde la carpeta 'public'
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');  // Enviar el archivo HTML principal
});
server.listen(3000, () => {
    console.log('Servidor escuchando en http://localhost:3000');
});  // Iniciar el servidor en el puerto 3000       
