document.getElementById("registroForm").addEventListener("submit", function(event) {
    event.preventDefault();
    let nombre = document.getElementById("nombre").value;
    let correo = document.getElementById("correo").value;
    
    alert(`¡Registro exitoso!\nNombre: ${nombre}\nCorreo: ${correo}`);
});

document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();
    let correo = document.getElementById("correoLogin").value;
    let contrasena = document.getElementById("contrasena").value;
    
    alert(`¡Inicio de sesión exitoso!\nCorreo: ${correo}\nContraseña: ${contrasena}`);
}); 

document.getElementById("recuperarForm").addEventListener("submit", function(event) {
    event.preventDefault();
    let correo = document.getElementById("correoRecuperar").value;
    
    alert(`¡Correo de recuperación enviado a ${correo}!`);
});

function mostrarRegistro() {
    document.getElementById("registro").style.display = "block";
    document.getElementById("login").style.display = "none";
    document.getElementById("recuperar").style.display = "none";
}   
function mostrarLogin() {
    document.getElementById("registro").style.display = "none";
    document.getElementById("login").style.display = "block";
    document.getElementById("recuperar").style.display = "none";
}   