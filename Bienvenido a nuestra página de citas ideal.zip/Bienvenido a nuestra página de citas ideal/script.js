function uploadFile() {
    const fileInput = document.getElementById("fileInput");
    const gallery = document.getElementById("gallery");

    if (fileInput.files.length > 0) {
        const file = fileInput.files[0];
        const fileURL = URL.createObjectURL(file);
        const element = file.type.startsWith("image") ? "img" : "video";

        const mediaElement = document.createElement(element);
        mediaElement.src = fileURL;
        mediaElement.controls = true;
        gallery.appendChild(mediaElement);
    }
}
function clearGallery() {
    const gallery = document.getElementById("gallery");
    while (gallery.firstChild) {
        gallery.removeChild(gallery.firstChild);
    }
}
function downloadFile() {
    const fileInput = document.getElementById("fileInput");
    if (fileInput.files.length > 0) {
        const file = fileInput.files[0];
        const link = document.createElement("a");
        link.href = URL.createObjectURL(file);
        link.download = file.name;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}   
function deleteFile() { 
    const fileInput = document.getElementById("fileInput");
    if (fileInput.files.length > 0) {
        fileInput.value = ""; // Clear the file input
        clearGallery(); // Clear the gallery
    }
}   
